package com.example.theaterlist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
