import 'package:theaterlist/screens/showtime_screen.dart';
import 'package:flutter/material.dart';
import '../model/theater.dart';

class TheaterCard extends StatefulWidget {
  final Theater theater;
  const TheaterCard({required this.theater, Key? key}) : super(key: key);

  @override
  _TheaterCard createState() => _TheaterCard();
}

class _TheaterCard extends State<TheaterCard> {
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) {
              return ShowtimeScreen(
                theaterId: widget.theater.id,
              );
            },
          ),
        );
      },
      child: Container(
        width: width,
        padding: const EdgeInsets.fromLTRB(20, 15, 20, 15),
        // color: whitePrimary,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(3),
              topRight: Radius.circular(3),
              bottomLeft: Radius.circular(3),
              bottomRight: Radius.circular(3)),
          boxShadow: [
            BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 3,
                blurRadius: 4,
                offset: const Offset(0, 3)),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.theater.name,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(
              height: 5,
            ),
            Row(
              children: [
                const Icon(Icons.location_on),
                Expanded(
                  child: Text(
                    widget.theater.location,
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.phone),
                    Text(
                      widget.theater.tel,
                      style: const TextStyle(fontSize: 14),
                    ),
                  ],
                ),
                const Icon(Icons.keyboard_arrow_right_rounded),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
