import 'package:flutter/material.dart';

class Button extends StatelessWidget {
  final onPress;
  final title;
  final color;
  final textColor;
  final fontsize;
  final width;
  final height;
  final radius;

  const Button(
      {this.color,
      this.onPress,
      this.title,
      this.textColor,
      this.fontsize,
      this.height = 50.0,
      this.width = 325.0,
      this.radius = 8.0});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPress,
      child: Container(
        width: width,
        padding: const EdgeInsets.symmetric(vertical: 15),
        child: Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: fontsize,
            fontFamily: 'Quicksand',
            color: textColor,
          ),
        ),
      ),
      style: ButtonStyle(
        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radius),
          ),
        ),
        backgroundColor: MaterialStateProperty.resolveWith<Color>(
          (Set<MaterialState> states) {
            if (onPress == null) return Colors.grey;
            if (states.contains(MaterialState.pressed)) return color;
            return color; // Use the component's default.
          },
        ),
      ),
    );
  }
}
