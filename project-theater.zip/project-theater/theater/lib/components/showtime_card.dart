import 'package:theaterlist/model/showtime.dart';
import 'package:theaterlist/screens/showtime_screen.dart';
import 'package:flutter/material.dart';
import '../model/theater.dart';

class ShowtimeCard extends StatefulWidget {
  final Showtime showtime;
  const ShowtimeCard({required this.showtime, Key? key}) : super(key: key);

  @override
  _ShowtimeCard createState() => _ShowtimeCard();
}

class _ShowtimeCard extends State<ShowtimeCard> {
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    return Container(
      width: width,
      padding: const EdgeInsets.fromLTRB(20, 15, 20, 15),
      // color: whitePrimary,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(3),
            topRight: Radius.circular(3),
            bottomLeft: Radius.circular(3),
            bottomRight: Radius.circular(3)),
        boxShadow: [
          BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 3,
              blurRadius: 4,
              offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.showtime.title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(
            height: 5,
          ),
          Row(
            children: [
              const Icon(Icons.calendar_month),
              const SizedBox(width: 5),
              Text(
                widget.showtime.date,
                style: const TextStyle(fontSize: 14),
              ),
              const SizedBox(width: 10),
              const Icon(Icons.alarm),
              const SizedBox(width: 5),
              Text(
                widget.showtime.duration.toString() + " minutes",
                style: const TextStyle(fontSize: 14),
              ),
            ],
          ),
          Container(
            child: renderTimes(widget.showtime.showtimes),
            margin: const EdgeInsets.only(top: 5),
          )
        ],
      ),
    );
  }

  Widget renderTimes(List<String> times) {
    return Wrap(
      children: times
          .map(
            (time) => Container(
              margin: const EdgeInsets.only(right: 5, top: 5),
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade800),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(time),
            ),
          )
          .toList(),
    );
  }
}
