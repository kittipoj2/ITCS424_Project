import 'package:flutter/material.dart';

const yellowPrimary = Color(0xFFEDC253);
const blackPrimaryFont = Color(0xFF343434);
const greySecondary = Color(0xFFEDEDED);

const BlackPrimaryFont = Color(0xFF343434);
const blackSecondaryFont = Color(0xFF707070);

const purplePrimary = Color(0xFF6D65AD);
const purpleSecondary = Color(0xFFDCD9F1);

const bluePrimary = Color(0xFF191970);

const whitePrimary = Color(0xFFF9F9F9);
const greyPrimary = Color(0xFFEFF0F6);

const grey = Color(0xFFCFCFCF);
