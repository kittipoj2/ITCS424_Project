import 'package:theaterlist/provider/authenticateProvider.dart';
import 'package:theaterlist/screens/landing_screen.dart';
import 'package:theaterlist/screens/login_screen.dart';
import 'package:theaterlist/screens/splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (ctx) => AuthenticateProvider()),
      ],
      child: Consumer<AuthenticateProvider>(
        builder: (ctx, auth, child) => MaterialApp(
          title: 'Theaterlist',
          debugShowCheckedModeBanner: false,
          home:
              // LandingScreen()

              auth.isAuth
                  ? const LandingScreen()
                  : FutureBuilder(
                      future: auth.tryAutoLogin(),
                      builder: (ctx, authResultSnapshot) =>
                          authResultSnapshot.connectionState ==
                                  ConnectionState.waiting
                              ? const SplashScreen()
                              : const LoginScreen(),
                    ),
        ),
      ),
    );
  }
}
