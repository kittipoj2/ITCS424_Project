// const apiEndpoint = "https://easy-theaterlist-api-sg-7woev2mtaq-as.a.run.app";
const apiEndpoint = "https://project-theater-66ovk5ioda-as.a.run.app/api";
const showTimesApiEndpoint = "https://showtimes.everyday.in.th/api";
