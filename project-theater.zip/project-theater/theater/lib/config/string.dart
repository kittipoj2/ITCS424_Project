const appName = "DekCare";
const descriptionText = "Application ...";
const usedEmailException = "This email is already used.";
const internetException = "Please check your internet connection.";
const generalException = "Something went wrong. Please try again later.";
const incorrectAuthException = "Your email or password is incorrect.";
String invalidException(type) {
  return "The $type is invalid.";
}
