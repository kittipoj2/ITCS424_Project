import 'package:theaterlist/model/showtime.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';
import '../config/api.dart';
import '../model/theater.dart';

class User {
  String email;
  User({required this.email});
}

showAlertDialog(BuildContext context) {
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      return const Center(
          child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white)));
    },
  );
}

class AuthenticateProvider with ChangeNotifier {
  String _token = "";
  User _user = User(
    email: '',
  );

  AuthenticateProvider();
  bool get isAuth {
    return _token.isNotEmpty;
  }

  String get token {
    return _token;
  }

  User get user {
    return _user;
  }

  User modifyUserData(response) {
    return User(
      email: response.data['email'],
    );
  }

  Future<void> login(String email, String password) async {
    final prefs = await SharedPreferences.getInstance();

    final response = await Dio().post(apiEndpoint + '/auth/login',
        data: {"email": email, "password": password});
    final token = response.data["token"];
    _token = token;

    final res = await Dio().get(apiEndpoint + '/auth/profile',
        options: Options(headers: {"Authorization": 'Bearer ' + _token}));
    _user = modifyUserData(res);
    prefs.setString('userToken', _token);
    await tryAutoLogin();
  }

  Future<User> fetchProfile() async {
    try {
      final res = await Dio().get(apiEndpoint + '/auth/profile',
          options: Options(headers: {"Authorization": 'Bearer ' + _token}));
      _user = modifyUserData(res);
    } catch (error) {}
    return _user;
  }

  Future<List<Theater>> fetchTheaters(int _currentPage, String name) async {
    try {
      int offset = (_currentPage - 1) * 20;
      final res = await Dio().get(showTimesApiEndpoint +
          '/v2/theater?offset=' +
          offset.toString() +
          '&search=' +
          name);
      final data = res.data['results'];

      final theaters = modifyTheaters(data);

      return theaters;
    } catch (error) {}
    return [];
  }

  Future<List<Showtime>> fetchShowtimes(
      int _theaterId, int _currentPage) async {
    try {
      int offset = (_currentPage - 1) * 20;
      String path =
          "/v2/theater/${_theaterId.toString()}/showtimes?offset=${offset.toString()}";
      final res = await Dio().get(showTimesApiEndpoint + path);
      final data = res.data['results'];

      final showtimes = modifyShowtimes(data);

      return showtimes;
    } catch (error) {
      print('error is');
      print(error);
    }
    return [];
  }

  Future<Theater> fetchTheater(int _id) async {
    final res =
        await Dio().get(showTimesApiEndpoint + '/v2/theater/' + _id.toString());
    final data = res.data;
    final theater = modifyTheater(data);
    return theater;
  }

  List<Theater> modifyTheaters(data) {
    List<Theater> list = [];
    data.forEach((el) {
      list.add(modifyTheater(el));
    });

    return list;
  }

  Theater modifyTheater(data) {
    Theater theater = Theater(
        id: data['id'],
        showTimes: data['showtimes'],
        name: data['english'],
        location: data['location'],
        tel: data['tel']);
    return theater;
  }

  List<Showtime> modifyShowtimes(data) {
    List<Showtime> list = [];
    data.forEach((el) {
      list.add(modifyShowtime(el));
    });

    return list;
  }

  Showtime modifyShowtime(data) {
    final temp = data['showtimes'];
    final showtimes =
        (temp as List)?.map((item) => item as String)?.toList() ?? [];
    Showtime showtime = Showtime(
        id: data['movie_id'],
        title: data['movie_title'],
        poster: data['movie_poster'],
        duration: data['movie_duration'],
        showtimes: showtimes,
        date: data['date'],
        audio: data['audio'],
        caption: data['caption']);
    return showtime;
  }

  Future<void> register(
    String email,
    String password,
  ) async {
    await Dio().post(apiEndpoint + '/auth/register', data: {
      "email": email,
      "password": password,
    });
  }

  Future<void> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    if (!prefs.containsKey('userToken')) return;

    String token = prefs.getString('userToken').toString();
    _token = token;
    try {
      final res = await Dio().get(apiEndpoint + '/auth/profile',
          options: Options(headers: {"Authorization": 'Bearer ' + _token}));
      _user = modifyUserData(res);
      notifyListeners();
    } catch (error) {
      prefs.clear();
      _token = "";
    }
  }

  Future<void> signOut() async {
    _token = "";
    final prefs = await SharedPreferences.getInstance();
    prefs.clear();
  }
}
