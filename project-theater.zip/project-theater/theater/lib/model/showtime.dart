class Showtime {
  final int id;
  final String title;
  final String poster;
  final int duration;
  final List<String> showtimes;
  final String date;
  final String audio;
  final String caption;
  Showtime(
      {required this.id,
      required this.title,
      required this.poster,
      required this.duration,
      required this.showtimes,
      required this.date,
      required this.audio,
      required this.caption});
}
