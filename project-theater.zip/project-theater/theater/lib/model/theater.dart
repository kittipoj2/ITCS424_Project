class Theater {
  final int id;
  final String showTimes;
  final String name;
  final String location;
  final String tel;
  Theater(
      {required this.id,
      required this.showTimes,
      required this.name,
      required this.location,
      required this.tel});
}
