import 'package:theaterlist/components/showtime_card.dart';
import 'package:theaterlist/model/showtime.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../components/constants.dart';

import '../provider/authenticateProvider.dart';
import '../model/theater.dart';

class ShowtimeScreen extends StatefulWidget {
  final int theaterId;
  const ShowtimeScreen({Key? key, required this.theaterId}) : super(key: key);

  @override
  _ShowtimeState createState() => _ShowtimeState();
}

class _ShowtimeState extends State<ShowtimeScreen> {
  int _theaterId = 0;
  int _page = 0;
  final int _limit = 20;
  bool _hasNextPage = true;
  bool _isFirstLoadRunning = false;
  bool _isLoadMoreRunning = false;

  @override
  void initState() {
    super.initState();
    _theaterId = widget.theaterId;
    _firstLoad();
    _controller = ScrollController()..addListener(_loadMore);
  }

  @override
  void dispose() {
    _controller.removeListener(_loadMore);
    super.dispose();
  }

  Theater _theater =
      Theater(id: 1, showTimes: '', name: '', location: '', tel: '');

  List<Showtime> _showtimes = [];

  final TextEditingController searchController = TextEditingController();

  void _firstLoad() async {
    setState(() {
      _isFirstLoadRunning = true;
      _page = 1;
    });
    try {
      final theater =
          await Provider.of<AuthenticateProvider>(context, listen: false)
              .fetchTheater(_theaterId);
      final showtimes =
          await Provider.of<AuthenticateProvider>(context, listen: false)
              .fetchShowtimes(_theaterId, _page);
      setState(() {
        _theater = theater;
        _showtimes = showtimes;
      });
    } catch (error) {}

    setState(() {
      _isFirstLoadRunning = false;
    });
  }

  // This function will be triggered whenver the user scroll
  // to near the bottom of the list view
  void _loadMore() async {
    if (_hasNextPage == true &&
        _isFirstLoadRunning == false &&
        _isLoadMoreRunning == false &&
        _controller.position.extentAfter < 300) {
      setState(() {
        _isLoadMoreRunning = true; // Display a progress indicator at the bottom
      });
      _page += 1; // Increase _page by 1
      try {
        final showtimes =
            await Provider.of<AuthenticateProvider>(context, listen: false)
                .fetchShowtimes(_theaterId, _page);

        if (showtimes.isNotEmpty) {
          setState(() {
            _showtimes.addAll(showtimes);
          });
        } else {
          setState(() {
            _hasNextPage = false;
          });
        }
      } catch (err) {}

      setState(() {
        _isLoadMoreRunning = false;
      });
    }
  }

  late ScrollController _controller;

  @override
  Widget build(BuildContext ctx) {
    return Container(
      color: purplePrimary,
      child: Scaffold(body: SafeArea(child: renderScreen(ctx))),
    );
  }

  void back() {
    Navigator.pop(context);
  }

  Widget renderScreen(BuildContext ctx) {
    return _isFirstLoadRunning
        ? const Center(
            child: CircularProgressIndicator(),
          )
        : Column(
            children: [
              renderTheater(ctx),
              const SizedBox(height: 10),
              Expanded(
                child: renderShowtimes(ctx),
              )
            ],
          );
  }

  Widget renderTheater(BuildContext ctx) {
    double width = MediaQuery.of(context).size.width;
    return Container(
      // width: width,
      color: bluePrimary,
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: back,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width - 80),
                child: Text(
                  _theater.name,
                  style: const TextStyle(
                      fontSize: 20,
                      color: whitePrimary,
                      fontFamily: 'Quicksand'),
                ),
              ),
              Row(
                children: [
                  const Icon(Icons.location_on, color: Colors.white),
                  Text(
                    _theater.location,
                    style: const TextStyle(fontSize: 14, color: Colors.white),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const Icon(Icons.phone, color: Colors.white),
                  Text(
                    _theater.tel,
                    style: const TextStyle(fontSize: 14, color: Colors.white),
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget renderShowtimes(BuildContext ctx) {
    return Column(
      children: [
        Expanded(
          child: ListView.separated(
            controller: _controller,
            separatorBuilder: (BuildContext context, int index) {
              return const SizedBox(height: 20);
            },
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
            itemCount: _showtimes.length,
            itemBuilder: (context, index) {
              return ShowtimeCard(showtime: _showtimes[index]);
            },
          ),
        ),
        if (_isLoadMoreRunning == true)
          const Padding(
              padding: EdgeInsets.only(top: 10, bottom: 40),
              child: Center(child: CircularProgressIndicator())),
      ],
    );
  }
}
