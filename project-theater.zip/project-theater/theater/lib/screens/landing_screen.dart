import 'package:theaterlist/components/theater_card.dart';
import 'package:theaterlist/screens/login_screen.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../components/constants.dart';

import '../provider/authenticateProvider.dart';

class LandingScreen extends StatefulWidget {
  const LandingScreen({Key? key}) : super(key: key);

  @override
  _LandingState createState() => _LandingState();
}

class _LandingState extends State<LandingScreen> {
  int _page = 0;
  final int _limit = 20;
  bool _hasNextPage = true;
  bool _isFirstLoadRunning = false;
  bool _isLoadMoreRunning = false;

  List _theaters = [];
  User _user = User(email: '');

  final TextEditingController searchController = TextEditingController();

  void _firstLoad() async {
    print('first load');
    setState(() {
      _isFirstLoadRunning = true;
      _page = 1;
    });
    try {
      final theaters =
          await Provider.of<AuthenticateProvider>(context, listen: false)
              .fetchTheaters(_page, searchController.text.toString());
      final user =
          await Provider.of<AuthenticateProvider>(context, listen: false)
              .fetchProfile();
      setState(() {
        _theaters = theaters;
        _user = user;
      });
    } catch (err) {}

    setState(() {
      _isFirstLoadRunning = false;
    });
  }

  // This function will be triggered whenver the user scroll
  // to near the bottom of the list view
  void _loadMore() async {
    if (_hasNextPage == true &&
        _isFirstLoadRunning == false &&
        _isLoadMoreRunning == false &&
        _controller.position.extentAfter < 300) {
      setState(() {
        _isLoadMoreRunning = true; // Display a progress indicator at the bottom
      });
      _page += 1; // Increase _page by 1
      try {
        final theaters =
            await Provider.of<AuthenticateProvider>(context, listen: false)
                .fetchTheaters(_page, searchController.text.toString());

        if (theaters.isNotEmpty) {
          setState(() {
            _theaters.addAll(theaters);
          });
        } else {
          setState(() {
            _hasNextPage = false;
          });
        }
      } catch (err) {}

      setState(() {
        _isLoadMoreRunning = false;
      });
    }
  }

  // The controller for the ListView
  late ScrollController _controller;

  @override
  void initState() {
    super.initState();
    _firstLoad();
    _controller = ScrollController()..addListener(_loadMore);
  }

  @override
  void dispose() {
    _controller.removeListener(_loadMore);
    super.dispose();
  }

  @override
  Widget build(BuildContext ctx) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Container(
      color: purplePrimary,
      child: Scaffold(
          body: SafeArea(
        child: Column(
          children: [
            renderUserProfile(ctx),
            renderSearch(ctx),
            Expanded(
              child: renderTheaters(ctx),
            )
          ],
        ),
      )),
    );
  }

  void signOut() async {
    try {
      await Provider.of<AuthenticateProvider>(context, listen: false).signOut();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) {
            return const LoginScreen();
          },
        ),
      );
    } catch (error) {
      Navigator.pop(context);
    }
  }

  Widget renderUserProfile(BuildContext ctx) {
    double width = MediaQuery.of(context).size.width;
    return Container(
      width: width,
      color: bluePrimary,
      padding: const EdgeInsets.all(20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width - 100),
            child: Text(
              'Hi, ' + _user.email,
              style: const TextStyle(
                  fontSize: 20, color: whitePrimary, fontFamily: 'Quicksand'),
            ),
          ),
          IconButton(
            icon: const Icon(
              Icons.logout,
              color: Colors.white,
            ),
            onPressed: () {
              print('logout');
              signOut();
            },
          ),
        ],
      ),
    );
  }

  Widget renderSearch(BuildContext ctx) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              height: 55,
              decoration: BoxDecoration(
                color: greyPrimary,
                borderRadius: BorderRadius.circular(8),
              ),
              child: TextField(
                keyboardType: TextInputType.text,
                textInputAction: TextInputAction.search,
                controller: searchController,
                onSubmitted: (value) {
                  _firstLoad();
                },
                onChanged: (value) {
                  if (value.isEmpty) {
                    _firstLoad();
                  }
                },
                decoration: InputDecoration(
                  hintText: 'Theater name',
                  hintStyle: TextStyle(fontFamily: 'Quicksand', fontSize: 15),
                  border: InputBorder.none,
                  suffixIcon: IconButton(
                    onPressed: () {
                      _firstLoad();
                    },
                    icon: const Icon(Icons.search),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget renderTheaters(BuildContext ctx) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return _isFirstLoadRunning
        ? const Center(
            child: const CircularProgressIndicator(),
          )
        : Column(
            children: [
              Expanded(
                child: ListView.separated(
                  controller: _controller,
                  separatorBuilder: (BuildContext context, int index) {
                    return const SizedBox(height: 20);
                  },
                  padding:
                      const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
                  itemCount: _theaters.length,
                  itemBuilder: (context, index) {
                    return TheaterCard(theater: _theaters[index]);
                  },
                ),
              ),
              if (_isLoadMoreRunning == true)
                const Padding(
                  padding: EdgeInsets.only(top: 10, bottom: 40),
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                ),

              // When nothing else to load
              if (_hasNextPage == false)
                Container(
                  padding: const EdgeInsets.only(top: 30, bottom: 40),
                  color: Colors.amber,
                  child: const Center(
                    child: Text('You have fetched all of the content'),
                  ),
                ),
            ],
          );
  }
}
