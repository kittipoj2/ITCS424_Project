import 'package:theaterlist/components/utils.dart';
import 'package:theaterlist/screens/login_screen.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../components/button.dart';
import '../components/constants.dart';
import '../provider/authenticateProvider.dart';

class RegisterScreen extends StatefulWidget {
  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

showAlertDialog(BuildContext context) {
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      return const Center(
          child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white)));
    },
  );
}

bool _passwordVisible = false;
bool _confirmPasswordVisible = false;

class _RegisterScreenState extends State<RegisterScreen> {
  @override
  var emailCheck = '';
  var passwordCheck = '';
  var confirmPasswordCheck = '';
  var firstnameCheck = '';
  var lastnameCheck = '';
  var emailCheckUsed = '';

  bool passwordEqual = true;

  var emailCheckError = '';
  var passwordCheckError = '';
  var confirmPasswordCheckError = '';

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  final ScrollController _scrollController = ScrollController();
  bool isEmailError = false,
      isPasswordError = false,
      isConfirmPasswordError = false,
      isPasswordNotMatchError = false;
  bool isLoading = false;

  bool validate() {
    isEmailError = false;
    isPasswordError = false;
    isConfirmPasswordError = false;
    isPasswordNotMatchError = false;
    String email = emailController.text.toString();
    String password = passwordController.text.toString();
    String confirmPassword = confirmPasswordController.text.toString();
    setState(() {
      isEmailError = email.isEmpty;
      isPasswordError = password.isEmpty;
      isConfirmPasswordError = confirmPassword.isEmpty;
      isPasswordNotMatchError = !(password == confirmPassword);
    });
    return isEmailError ||
        isPasswordError ||
        isConfirmPasswordError ||
        isPasswordNotMatchError;
  }

  void register() async {
    try {
      if (validate()) return;
      setState(() {
        isLoading = true;
      });
      print('Api calling');
      await Provider.of<AuthenticateProvider>(context, listen: false).register(
        emailController.text,
        passwordController.text,
      );

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) {
            return LoginScreen();
          },
        ),
      );
    } catch (error) {
      if (error is DioError) {
        String msg = error.response?.data['msg'];
        Utils.showErrorDialog(context, 'Error', msg);
        return;
      }
      Utils.showErrorDialog(
          context, 'Something went wrong', 'Please try again later.');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    @override
    double width = MediaQuery.of(context).size.width;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Container(
        color: whitePrimary,
        child: SafeArea(
          child: Scaffold(
            backgroundColor: whitePrimary,
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              bottomOpacity: 0.0,
              elevation: 0.0,
              leading: IconButton(
                  icon: const Icon(Icons.arrow_back),
                  color: Colors.black54,
                  onPressed: () {
                    Navigator.pop(context);
                  }),
              centerTitle: true,
            ),
            body: SingleChildScrollView(
              controller: _scrollController,
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 40),
                      child: Container(
                        alignment: Alignment.topLeft,
                        child: const Text(
                          'Let’s get start',
                          style: TextStyle(
                              // color: kPrimaryFont,
                              fontSize: 24,
                              fontFamily: 'Quicksand',
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 40),
                      child: Container(
                        alignment: Alignment.topLeft,
                        child: const Text(
                          'Create an account to explore theaters and movies.',
                          style: TextStyle(
                            // color: kPrimaryFont,
                            fontSize: 14,
                            fontFamily: 'Quicksand',
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                        margin: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 40),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 5),
                        width: width,
                        height: 55,
                        decoration: BoxDecoration(
                          color: greyPrimary,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: TextField(
                          onChanged: (text) {
                            setState(() {
                              emailCheck = text;
                              setState(() {
                                emailCheckError = '';
                              });
                            });
                          },
                          keyboardType: TextInputType.emailAddress,
                          controller: emailController,
                          decoration: const InputDecoration(
                              hintText: 'Email',
                              hintStyle: TextStyle(
                                  fontFamily: 'Quicksand', fontSize: 15),
                              border: InputBorder.none),
                        )),
                    isEmailError
                        ? renderErorMessage('Email is required.')
                        : Container(),
                    Container(
                        margin: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 40),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 5),
                        width: width,
                        height: 55,
                        decoration: BoxDecoration(
                          color: greyPrimary,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: TextField(
                          onChanged: (text) {
                            passwordCheck = text;

                            setState(() {
                              passwordCheckError = '';
                              passwordEqual = true;
                            });
                          },
                          controller: passwordController,
                          obscureText: !_passwordVisible,
                          decoration: InputDecoration(
                              hintText: 'Password',
                              hintStyle: const TextStyle(
                                  fontFamily: 'Quicksand', fontSize: 15),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _passwordVisible
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color:
                                      const Color.fromARGB(255, 121, 121, 121),
                                ),
                                onPressed: () {
                                  setState(() {
                                    _passwordVisible = !_passwordVisible;
                                  });
                                },
                              ),
                              border: InputBorder.none),
                        )),
                    isPasswordError
                        ? renderErorMessage('Password is required.')
                        : Container(),
                    Container(
                        margin: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 40),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 5),
                        width: width,
                        height: 55,
                        decoration: BoxDecoration(
                          color: greyPrimary,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: TextField(
                          onChanged: (text) {
                            confirmPasswordCheck = text;
                            setState(() {
                              confirmPasswordCheckError = '';
                              passwordEqual = true;
                            });
                          },
                          controller: confirmPasswordController,
                          obscureText: !_confirmPasswordVisible,
                          decoration: InputDecoration(
                              hintText: 'Confirm Password',
                              hintStyle: const TextStyle(
                                  fontFamily: 'Quicksand', fontSize: 15),
                              suffixIcon: IconButton(
                                icon: Icon(
                                  _confirmPasswordVisible
                                      ? Icons.visibility_off
                                      : Icons.visibility,
                                  color:
                                      const Color.fromARGB(255, 121, 121, 121),
                                ),
                                onPressed: () {
                                  setState(() {
                                    _confirmPasswordVisible =
                                        !_confirmPasswordVisible;
                                  });
                                },
                              ),
                              border: InputBorder.none),
                        )),
                    isConfirmPasswordError
                        ? renderErorMessage('Confirm password is required.')
                        : Container(),
                    isPasswordNotMatchError &&
                            !isPasswordError &&
                            !isConfirmPasswordError
                        ? renderErorMessage('Password are not match')
                        : Container(),
                    const SizedBox(
                      height: 23,
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 40),
                      child: Button(
                        onPress: isLoading
                            ? null
                            : () {
                                register();
                              },
                        color: bluePrimary,
                        textColor: whitePrimary,
                        fontsize: 15.00,
                        title: 'Create account',
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(top: 14.5),
                          child: Text(
                            'Already have an account?',
                            style: TextStyle(
                              // color: kPrimaryFont,
                              fontSize: 14,
                              fontFamily: 'Quicksand',
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            setState(() {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) {
                                    return const LoginScreen();
                                  },
                                ),
                              );
                            });
                          },
                          child: const Text(
                            'login here',
                            style: TextStyle(
                                fontSize: 14,
                                fontFamily: 'Quicksand',
                                decoration: TextDecoration.underline,
                                color: bluePrimary,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget renderErorMessage(String errorMessage) {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 0, left: 40),
          child: Text(
            errorMessage,
            style: const TextStyle(
              fontSize: 14,
              fontFamily: 'Quicksand',
              color: Color.fromARGB(255, 197, 38, 38),
            ),
          ),
        ),
      ],
    );
  }
}
