const passport = require("passport");
const ErrorResponse = require("../utils/errorResponse");

const jwtAuthenicate = (req, res, next) => {
  passport.authenticate("jwt", { session: false }, (err, user) => {
    if (err || !user) {
      return next(new ErrorResponse("Unauthorize", 401))
    }
    req.user = user;
    return next();
  })(req, res, next);
}

module.exports = {
  jwtAuthenicate
}