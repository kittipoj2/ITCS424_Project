const express = require('express');

const { jwtAuthenicate } = require('../middlewares/jwtAuthenticate');

const router = express.Router();
const {

  regisController,
  loginController,
  getProfile
} = require('../controllers/authController');

router.post('/login', loginController);
router.post('/register', regisController);
router.get('/profile', jwtAuthenicate, getProfile);

module.exports = router