const jwt = require('jsonwebtoken');

const jwtSecret = process.env.JWT_SECRET;
const jwtAlgo = process.env.JWT_ALGO;

const jwtCookieSignOption = {
  algorithm: jwtAlgo,
  expiresIn: '30d',
}

const generateCookieJWT = (payload) => {
  return jwt.sign({ id: payload, role: 'user' }, jwtSecret, jwtCookieSignOption)
}

module.exports = {
  generateCookieJWT
}