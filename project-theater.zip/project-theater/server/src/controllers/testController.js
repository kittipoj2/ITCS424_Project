exports.test = async (req, res, next) => {
  try {
    console.log(process.env.FOO);
    res.send('hello');
  } catch (err) {
    res.send(err)
  }
}