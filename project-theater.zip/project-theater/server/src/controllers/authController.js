const bcrypt = require('bcryptjs');
const pool = require('../database/db');
const { v4: uuidv4 } = require('uuid');
const ErrorResponse = require('../utils/errorResponse');
const { generateCookieJWT } = require('../utils/jwt');

const validateEmail = (email) => {
  return String(email)
    .toLowerCase()
    .match(
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
};

exports.regisController = async (req, res, next) => {
  try {
    const client = await pool.connect();
    const user = req.body;

    const isEmailValid = validateEmail(user.email);
    if (!isEmailValid) {
      return res.status(400).send({ msg: 'Email is invalid.' });
    }

    const isPasswordValid = user.password.length >= 8;
    if (!isPasswordValid) {
      return res.status(400).send({ msg: 'Password must be at least 8 characters.' })
    }

    // Find for existing email
    const existingUser = await client.query(`SELECT email from defaultdb.user where email = $1`, [user.email]);
    if (existingUser.rowCount > 0) {
      return res.status(400).send({ msg: 'Email is already used.' });
    }

    user.id = uuidv4()
    user.password = bcrypt.hashSync(user.password)

    await client.query(`INSERT INTO defaultdb.user values($1,$2,$3,$4,$5)`, [user.id, user.email, user.password, user.firstname, user.lastname]);
    client.release();
    res.status(201).send();
  } catch (error) {
    return next(new ErrorResponse(error.message, 500))
  }
}


exports.loginController = async (req, res, next) => {
  try {
    const client = await pool.connect();
    const { email, password } = req.body;

    const auth = await client.query('SELECT id, password from defaultdb.user where email = $1', [email]);
    if (auth.rowCount !== 1) {
      return res.status(400).send({ msg: 'Email or password is incorrect.' });
    }

    const passwordMatch = await bcrypt.compare(password, auth.rows[0].password);
    if (!passwordMatch) {
      return res.status(400).send({ msg: 'Email or password is incorrect.' });
    }

    const userId = auth.rows[0].id;
    const token = generateCookieJWT(userId);
    client.release();
    res.cookie('jwt', token);
    res.status(201).send({ token });
  } catch (error) {
    return next(new ErrorResponse(error.message, 500))
  }
}

exports.logoutController = (req, res) => {
  res.clearCookie('jwt')
  res.status(200).send()
}


exports.getProfile = async (req, res, next) => {
  try {
    if (req.user) {
      const client = await pool.connect();
      const auth = (await client.query(`SELECT * from defaultdb.user where id = '${req.user.id}'`));
      if (auth.rowCount !== 1) {
        return next(new ErrorResponse('Unauthorize', 401))
      }
      const result = auth.rows[0];
      delete result.password;
      client.release();

      res.send(result);
    } else {
      return next(new ErrorResponse('Unauthorize', 401))
    }
  } catch (error) {
    return next(new ErrorResponse(error.messgae, 500));
  }
}
