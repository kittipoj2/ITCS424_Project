const express = require('express');
const errorHandler = require('./middlewares/error');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const passport = require('passport')
require('dotenv').config();

const ConfigRoute = require('./routes/configRoute')
const passportConfig = require('./config/passport')

const app = express()

app.use(express.json())
app.use(cookieParser())

const corsMiddleware = cors({
  credentials: true,
  origin: ['http://localhost:3000', 'http://52.184.16.127'],
  methods: ['GET', 'PUT', 'POST', 'PATCH', 'DELETE']
})

app.use(corsMiddleware)
app.options('*', cors(corsMiddleware))

app.use(corsMiddleware)

passportConfig(passport)
app.use(passport.initialize())

app.use('/api', ConfigRoute)
app.use(errorHandler)


module.exports = app